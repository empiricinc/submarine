<section class="secMainWidthFilter">
	<!-- <section class="secFormLayout"> -->
		<div class="topNavFilter">
				
		</div>
		<div class="row marg">
			<div class="col-lg-12">
				<div id="complaints-handler">
					<?= $complaints_table; ?>
				</div>
			</div>
		</div>
		
	<!-- </section> -->
</section>