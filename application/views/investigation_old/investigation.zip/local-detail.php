<section class="secMainWidth">
<section class="secFormLayout">
	<div class="mainInputBg">
		<div class="row">
			<div class="col-lg-12">
				<div class="tabelHeading">
					<h3><?= $title; ?></h3>
				</div>
			</div>
		</div>
		<div class="solidLine"></div>
		<div class="panel panel-default mlr-15">
			<div class="panel-heading">
				<h4>Complaint Detail</h4>
			</div>
			<div class="panel-body">
				<div class="row ptb-5">
					<div class="col-lg-12 ptb-5">
						<div class="col-lg-2"><strong>Compalint No</strong></div>
						<div class="col-lg-4"><?= $detail->complaint_no; ?></div>

						<div class="col-lg-2"><strong>Date</strong></div>
						<div class="col-lg-4"><?= date('d-m-Y', strtotime($detail->created_at)); ?></div>
					</div>
					<div class="col-lg-12 ptb-5">
						<div class="col-lg-2"><strong>Complainee Name</strong></div>
						<div class="col-lg-4"><?= $detail->name; ?></div>

						<div class="col-lg-2"><strong>Contact number</strong></div>
						<div class="col-lg-4"><?= $detail->contact_no; ?></div>
					</div>
				
					<div class="col-lg-12 ptb-5">
						<div class="col-lg-2"><strong>Email address</strong></div>
						<div class="col-lg-4"><?= $detail->email; ?></div>
					</div>

					<div class="col-lg-12 ptb-5 mt-15">
						<div class="col-lg-2"><strong>Subject</strong></div>
						<div class="col-lg-4"><?= $detail->subject; ?></div>
					</div>
					<div class="col-lg-12 ptb-5">
						<div class="col-lg-2"><strong>Description</strong></div>
						<div class="col-lg-4"><?= $detail->complaint_desc; ?></div>
					</div>

					<div class="col-lg-12"><hr></div>
					<div class="col-lg-12">
						<div class="col-lg-2"><strong>Province</strong></div>
						<div class="col-lg-4"><?= $detail->province; ?></div>

						<div class="col-lg-2"><strong>District</strong></div>
						<div class="col-lg-4"><?= $detail->district; ?></div>
					</div>

				
					<div class="col-lg-12 ptb-5">
						<div class="col-lg-2"><strong>Tehsil</strong></div>
						<div class="col-lg-4"><?= $detail->tehsil; ?></div>

						<div class="col-lg-2"><strong>Union council</strong></div>
						<div class="col-lg-4"><?= $detail->uc; ?></div>
					</div>
				</div>
			</div>
		</div>
		<!-- ./ Complaint panel -->


		<!-- Files and Remarks -->
		<?php if(!empty($remarks_and_files)): ?>
		<div class="panel panel-default mlr-15">
			<div class="panel-heading">
				<h4>Investigation Remarks and Detail</h4>
			</div>
			<div class="panel-body">
			<?php $marginLeft=0; for ($i=0; $i < count($remarks_and_files); $i++) { 
				$employee_name = ucfirst($remarks_and_files[$i]['first_name'])." ".ucfirst($remarks_and_files[$i]['last_name']);
			?>
				<?php if($remarks_and_files[$i]['send_from'] == 'head'):
						$sender = $employee_name . ' (Project Head)';
						$marginLeft = 0;
					  elseif($remarks_and_files[$i]['send_from'] == 'legal'):
					  	$sender = $employee_name . ' (Legal)';
					  	$marginLeft = 10;
					  elseif($remarks_and_files[$i]['send_from'] == 'local'):
					  	$sender = 'You';
					  	$marginLeft = 20;
					  endif;
				 ?>
				<div class="col-lg-11">
				<div class="col-lg-12 well mb-5" style="margin-left: <?= $marginLeft; ?>px;">
					<div class="col-lg-12 mb-10">
						<strong><?= $sender; ?></strong>
					</div>	
					<div class="col-lg-12">
						<?= $remarks_and_files[$i]['sender_remarks']; ?>
					</div>	
					<?php 
						for ($j=0; $j < $remarks_and_files[$i]['number_of_files']; $j++) { 
							$url = base_url().'uploads/investigation_files/'. $remarks_and_files[$i][$j]['file_name'];
					?>
					<div class="col-lg-12">
						<a href="<?= $url; ?>" download><?= $remarks_and_files[$i][$j]['original_name']; ?></a>
					</div>
					<?php } ?>
					<div class="col-lg-12 mt-15">
						<span class="label label-primary"><?= date('d-m-Y', strtotime($remarks_and_files[$i]['r_date'])); ?></span>
					</div>
					
				</div>
				</div>

			<?php } ?>

			<!-- closing remarks -->
			<?php if($detail->status == 'resolved'): ?>
				<div class="col-lg-11">
					<div class="col-lg-12 well mb-5">
						<div class="col-lg-12 mb-10">
							<strong>Project Head</strong>
						</div>
						<div class="col-lg-12">
							<?= $detail->closing_remarks; ?>
						</div>
						<div class="col-lg-12 mt-15">
							<span class="label label-primary"><?= date('d-m-Y', strtotime($detail->remarks_at)); ?></span>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- ./ closing remarks -->
			</div>
		</div>
		<?php endif; ?>
		<!-- ./ End of Files and Remarks -->

		<div class="row">
			<!-- <div class="col-lg-12"><hr></div> -->
			<!-- Form -->
				<div class="col-lg-12">
					<form action="<?= base_url(); ?>Investigation/local_resolve" method="POST" enctype="multipart/form-data" id="legal-form">
						<div class="inputFormMain col-lg-12">
							<input type="hidden" name="investigation_id" value="<?= $detail->id; ?>">
							<input type="hidden" name="complaint_id" id="complaint_id" 
							value="<?= $detail->id; ?>">
							<input type="hidden" name="employee_id" id="employee_id" value="<?= $detail->receiver; ?>">
							<textarea name="remarks" id="remarks" class="form-control resize-v" rows="5" required="required" placeholder="Your remarks about the complaint..."></textarea>	
						</div>
						<div class="inputFormMain col-lg-12">
							<input type="file" name="docs[]" multiple>
						</div>

						<div class="submitBtn col-lg-2 pr-0">
							<button type="submit" class="btn btnSubmit"><i class="fa fa-check"></i> Resolve </button>
						</div>	
					</form>
				</div>
			<!-- ./ Form -->
		</div>

	</div>
</section>
</section>