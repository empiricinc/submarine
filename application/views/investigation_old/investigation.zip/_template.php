<?php $this->load->view('investigation/components/header'); ?>
<?php 
 $this->load->view('investigation/components/navbar'); 
?>

<?php echo $content;  ?>

<?php $this->load->view('investigation/components/footer'); ?>