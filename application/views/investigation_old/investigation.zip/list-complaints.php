<section class="secMainWidthFilter">

	<div class="topNavFilter">
			
	</div>
	<div class="row marg">
		<div class="col-lg-12">
			<div id="complaints-handler" class="<?= $view_print; ?>">
				<?= $complaints_table; ?>
			</div>
		</div>
	</div>

</section>